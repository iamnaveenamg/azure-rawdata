from pyspark import pipelines as dp
from pyspark.sql.functions import *
from pyspark.sql.window import Window

@dp.table(
    name="DimCustomer",
    comment="Customer Dimension"
)
def dim_customer():

    df = spark.read.table("db_mgn.silversales.cdmcustomer")

    # Hash of all attributes (for change detection)
    df = df.withColumn(
        "HashKey",
        sha2(concat_ws("|", *df.columns), 256)
    )

    # Generate Surrogate Key
    window = Window.orderBy("CustomerID")   # Business Key

    df = df.withColumn(
        "CustomerSK",
        row_number().over(window)
    )

    return df