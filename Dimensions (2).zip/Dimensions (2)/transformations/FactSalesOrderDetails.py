from pyspark import pipelines as dp
from pyspark.sql.functions import *
from pyspark.sql.window import Window

@dp.table(
    name="FactSalesOrderDetails",
    comment="Sales Order Details Fact"
)
def fact_sales_order_details():

    # Source fact
    fact_df = spark.read.table("db_mgn.silversales.cdmsalesorderdetails")

    # Product dimension
    dim_product = (
        spark.read.table("DimProduct")
        .select("SalesOrderID", "ProductID", "ProductSK")
    )

    # Join on SalesOrderID + ProductID
    fact_df = fact_df.join(
        dim_product,
        on=["SalesOrderID", "ProductID"],
        how="left"
    )

    # Generate Fact Surrogate Key
    window = Window.orderBy("SalesOrderID", "ProductID")

    fact_df = fact_df.withColumn(
        "SalesOrderDetailsSK",
        row_number().over(window)
    )

    return fact_df