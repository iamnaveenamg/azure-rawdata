from pyspark import pipelines as dp
from pyspark.sql.functions import *
from pyspark.sql.window import Window

@dp.table(
    name="DimProduct",
    comment="Product Dimension"
)
def dim_product():

    df = spark.read.table("db_mgn.silversales.cdmproduct")

    # Add HashKey for change detection
    df = df.withColumn(
        "HashKey",
        sha2(concat_ws("|", *df.columns), 256)
    )

    # Generate Surrogate Key (SK)
    window = Window.orderBy("ProductID")  # Business Key

    df = df.withColumn(
        "ProductSK",
        row_number().over(window)
    )

    return df